<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no_pembelian      = mysqli_real_escape_string($koneksi, $_POST['no_pembelian']);
    $tanggal_pembelian = mysqli_real_escape_string($koneksi, $_POST['tanggal_pembelian']);
    $id_supplier       = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
    $total_barangall   = (int)$_POST['total_barangall'];
    $total_hargaall    = (int)$_POST['total_hargaall'];

    $kd_barang_arr     = $_POST['kd_barang'];
    $kode_jenis_arr    = $_POST['kode_jenis'];
    $jumlah_barang_arr = $_POST['jumlah_barang'];
    $harga_barang_arr  = $_POST['harga_barang'];

    // Simpan header pembelian
    $q1 = "INSERT INTO tb_pembelian 
            (no_pembelian, tanggal_pembelian, id_supplier, total_barangall, total_hargaall)
            VALUES
            ('$no_pembelian', '$tanggal_pembelian', '$id_supplier', '$total_barangall', '$total_hargaall')";

    if (!mysqli_query($koneksi, $q1)) {
        header("Location: input.php?pesan=error");
        exit;
    }

    // Simpan detail pembelian + update stok
    $no_item = 1;
    $sukses  = true;
    foreach ($kd_barang_arr as $i => $kd) {
        $kd        = mysqli_real_escape_string($koneksi, $kd);
        $jenis     = mysqli_real_escape_string($koneksi, $kode_jenis_arr[$i]);
        $jumlah    = (int)$jumlah_barang_arr[$i];
        $harga     = (int)$harga_barang_arr[$i];
        $total_sub = $jumlah * $harga;

        $q2 = "INSERT INTO detail_pembelian
                (no_pembelian, kd_barang, kode_jenis, jumlah_barang, harga_barang, total_harga, no_item)
                VALUES
                ('$no_pembelian', '$kd', '$jenis', '$jumlah', '$harga', '$total_sub', '$no_item')";

        if (!mysqli_query($koneksi, $q2)) {
            $sukses = false;
        }

        // Update stok barang bertambah
        mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok + $jumlah WHERE kd_barang = '$kd'");

        $no_item++;
    }

    if ($sukses) {
        header("Location: index.php?pesan=input");
    } else {
        header("Location: index.php?pesan=error");
    }
    exit;
} else {
    header("Location: input.php");
    exit;
}
?>
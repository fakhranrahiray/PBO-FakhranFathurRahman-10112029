<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $no = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Kembalikan stok dulu sebelum hapus
    $qDetail = mysqli_query($koneksi, "SELECT kd_barang, jumlah_barang FROM detail_pembelian WHERE no_pembelian = '$no'");
    while ($d = mysqli_fetch_array($qDetail)) {
        $kd  = mysqli_real_escape_string($koneksi, $d['kd_barang']);
        $jml = (int)$d['jumlah_barang'];
        mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok - $jml WHERE kd_barang = '$kd'");
    }

    // Hapus detail pembelian dulu
    mysqli_query($koneksi, "DELETE FROM detail_pembelian WHERE no_pembelian = '$no'");

    // Hapus header pembelian
    $query = "DELETE FROM tb_pembelian WHERE no_pembelian = '$no'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?pesan=hapus");
    } else {
        header("Location: index.php?pesan=error");
    }
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
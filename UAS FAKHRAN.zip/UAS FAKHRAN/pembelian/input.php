<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pembelian — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .detail-table { width:100%; border-collapse:collapse; margin-top:10px; }
        .detail-table th, .detail-table td { border:1px solid #ccc; padding:8px; text-align:center; }
        .detail-table th { background:#f0f0f0; }
        #total-info { margin-top:12px; font-size:15px; font-weight:bold; }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Tambah Transaksi Pembelian</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <a class="tombol" href="index.php">← Kembali</a>

    <h3>Form Tambah Pembelian</h3>
    <form action="input-aksi.php" method="POST" id="formPembelian">

        <table class="form-table">
            <tr>
                <td>No. Pembelian</td>
                <td><input type="text" name="no_pembelian" class="input-form" placeholder="Contoh: PBL001" required></td>
            </tr>
            <tr>
                <td>Tanggal Pembelian</td>
                <td><input type="date" name="tanggal_pembelian" class="input-form" value="<?php echo date('Y-m-d'); ?>" required></td>
            </tr>
            <tr>
                <td>Supplier</td>
                <td>
                    <select name="id_supplier" class="input-form" required>
                        <option value="">-- Pilih Supplier --</option>
                        <?php
                        include "../koneksi.php";
                        $sup = mysqli_query($koneksi, "SELECT * FROM tb_supplier ORDER BY nama_supplier ASC");
                        while ($s = mysqli_fetch_array($sup)):
                        ?>
                        <option value="<?php echo $s['id_supplier']; ?>"><?php echo htmlspecialchars($s['nama_supplier']); ?></option>
                        <?php endwhile; ?>
                    </select>
                </td>
            </tr>
        </table>

        <hr style="margin:20px 0;">
        <h4>📋 Detail Barang</h4>

        <table class="detail-table" id="tabelDetail">
            <thead>
                <tr>
                    <th>Barang</th>
                    <th>Jenis</th>
                    <th>Jumlah</th>
                    <th>Harga Beli</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="bodyDetail"></tbody>
        </table>

        <br>
        <button type="button" class="tombol" style="background:#555;" onclick="tambahBaris()">+ Tambah Barang</button>

        <div id="total-info">
            Total Barang: <span id="totalBarang">0</span> item &nbsp;|&nbsp;
            Total Harga: Rp <span id="totalHarga">0</span>
        </div>

        <input type="hidden" name="total_barangall" id="hiddenTotalBarang" value="0">
        <input type="hidden" name="total_hargaall"  id="hiddenTotalHarga"  value="0">

        <br>
        <button type="submit" class="tombol">💾 Simpan Pembelian</button>
        <a href="index.php" class="tombol" style="background:#888;">Batal</a>

    </form>
</div>

<script>
// Data barang dari PHP
const listBarang = [
    <?php
    $barang = mysqli_query($koneksi, "
        SELECT b.kd_barang, b.nama_barang, b.kode_jenis, b.harga_beli, j.jenis
        FROM tb_barang b
        LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis
        ORDER BY b.nama_barang ASC
    ");
    while ($b = mysqli_fetch_array($barang)) {
        echo "{kd: '{$b['kd_barang']}', nama: '".addslashes($b['nama_barang'])."', kode_jenis: '{$b['kode_jenis']}', namaJenis: '".addslashes($b['jenis'])."', harga: {$b['harga_beli']}},";
    }
    ?>
];

let noItem = 0;

function tambahBaris() {
    noItem++;
    const tbody = document.getElementById('bodyDetail');
    const tr    = document.createElement('tr');
    tr.id = 'baris-' + noItem;

    let opsiBarang = '<option value="">-- Pilih Barang --</option>';
    listBarang.forEach(function(b) {
        opsiBarang += `<option value="${b.kd}" data-jenis="${b.kode_jenis}" data-namajenis="${b.namaJenis}" data-harga="${b.harga}">${b.nama}</option>`;
    });

    tr.innerHTML = `
        <td>
            <select name="kd_barang[]" class="input-form" onchange="updateBaris(${noItem})" required>
                ${opsiBarang}
            </select>
            <input type="hidden" name="kode_jenis[]" id="jenis-${noItem}" value="">
        </td>
        <td id="nama-jenis-${noItem}">-</td>
        <td><input type="number" name="jumlah_barang[]" id="jumlah-${noItem}" class="input-form" min="1" value="1" oninput="hitungSubtotal(${noItem})" required></td>
        <td><input type="number" name="harga_barang[]"  id="harga-${noItem}"  class="input-form" min="0" value="0" oninput="hitungSubtotal(${noItem})" required></td>
        <td id="subtotal-${noItem}">Rp 0</td>
        <td><button type="button" class="tombol" style="background:#c0392b; padding:4px 10px;" onclick="hapusBaris(${noItem})">Hapus</button></td>
    `;
    tbody.appendChild(tr);
    updateTotal();
}

function updateBaris(n) {
    const select  = document.querySelector(`#baris-${n} select[name="kd_barang[]"]`);
    const opt     = select.options[select.selectedIndex];
    document.getElementById(`jenis-${n}`).value          = opt.dataset.jenis     || '';
    document.getElementById(`nama-jenis-${n}`).textContent = opt.dataset.namajenis || '-';
    document.getElementById(`harga-${n}`).value           = opt.dataset.harga     || 0;
    hitungSubtotal(n);
}

function hitungSubtotal(n) {
    const jumlah = parseInt(document.getElementById(`jumlah-${n}`).value) || 0;
    const harga  = parseInt(document.getElementById(`harga-${n}`).value)  || 0;
    document.getElementById(`subtotal-${n}`).textContent = 'Rp ' + (jumlah * harga).toLocaleString('id-ID');
    updateTotal();
}

function hapusBaris(n) {
    document.getElementById('baris-' + n).remove();
    updateTotal();
}

function updateTotal() {
    let totalBarang = 0, totalHarga = 0;
    const jumlahInputs = document.querySelectorAll('input[name="jumlah_barang[]"]');
    const hargaInputs  = document.querySelectorAll('input[name="harga_barang[]"]');
    jumlahInputs.forEach(function(el, i) {
        const jml  = parseInt(el.value) || 0;
        const hrg  = parseInt(hargaInputs[i].value) || 0;
        totalBarang += jml;
        totalHarga  += jml * hrg;
    });
    document.getElementById('totalBarang').textContent      = totalBarang;
    document.getElementById('totalHarga').textContent       = totalHarga.toLocaleString('id-ID');
    document.getElementById('hiddenTotalBarang').value      = totalBarang;
    document.getElementById('hiddenTotalHarga').value       = totalHarga;
}

// Langsung tampilkan 1 baris saat halaman dibuka
tambahBaris();
</script>

</body>
</html>
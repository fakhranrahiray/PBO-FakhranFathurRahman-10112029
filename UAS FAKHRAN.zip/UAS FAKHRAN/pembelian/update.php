<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $no_lama           = mysqli_real_escape_string($koneksi, $_POST['no_pembelian_lama']);
    $no_pembelian      = mysqli_real_escape_string($koneksi, $_POST['no_pembelian']);
    $tanggal_pembelian = mysqli_real_escape_string($koneksi, $_POST['tanggal_pembelian']);
    $id_supplier       = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
    $total_barangall   = (int)$_POST['total_barangall'];
    $total_hargaall    = (int)$_POST['total_hargaall'];

    $kd_barang_arr     = $_POST['kd_barang'];
    $kode_jenis_arr    = $_POST['kode_jenis'];
    $jumlah_barang_arr = $_POST['jumlah_barang'];
    $harga_barang_arr  = $_POST['harga_barang'];

    // Kembalikan stok lama sebelum update
    $qOldDetail = mysqli_query($koneksi, "SELECT kd_barang, jumlah_barang FROM detail_pembelian WHERE no_pembelian = '$no_lama'");
    while ($old = mysqli_fetch_array($qOldDetail)) {
        $kd_old  = mysqli_real_escape_string($koneksi, $old['kd_barang']);
        $jml_old = (int)$old['jumlah_barang'];
        mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok - $jml_old WHERE kd_barang = '$kd_old'");
    }

    // Hapus detail lama
    mysqli_query($koneksi, "DELETE FROM detail_pembelian WHERE no_pembelian = '$no_lama'");

    // Update header pembelian
    $q1 = "UPDATE tb_pembelian SET
                no_pembelian      = '$no_pembelian',
                tanggal_pembelian = '$tanggal_pembelian',
                id_supplier       = '$id_supplier',
                total_barangall   = '$total_barangall',
                total_hargaall    = '$total_hargaall'
            WHERE no_pembelian    = '$no_lama'";

    if (!mysqli_query($koneksi, $q1)) {
        header("Location: edit.php?id=$no_lama&pesan=error");
        exit;
    }

    // Simpan detail baru + update stok
    $no_item = 1;
    $sukses  = true;
    foreach ($kd_barang_arr as $i => $kd) {
        $kd        = mysqli_real_escape_string($koneksi, $kd);
        $jenis     = mysqli_real_escape_string($koneksi, $kode_jenis_arr[$i]);
        $jumlah    = (int)$jumlah_barang_arr[$i];
        $harga     = (int)$harga_barang_arr[$i];
        $total_sub = $jumlah * $harga;

        $q2 = "INSERT INTO detail_pembelian
                (no_pembelian, kd_barang, kode_jenis, jumlah_barang, harga_barang, total_harga, no_item)
                VALUES
                ('$no_pembelian', '$kd', '$jenis', '$jumlah', '$harga', '$total_sub', '$no_item')";

        if (!mysqli_query($koneksi, $q2)) {
            $sukses = false;
        }

        // Tambah stok baru
        mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok + $jumlah WHERE kd_barang = '$kd'");

        $no_item++;
    }

    if ($sukses) {
        header("Location: index.php?pesan=update");
    } else {
        header("Location: index.php?pesan=error");
    }
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
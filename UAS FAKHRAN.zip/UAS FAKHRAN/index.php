<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Informasi Gudang</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background: #f0f4f8;
            color: #2d3748;
            min-height: 100vh;
        }

        /* ===== HEADER ===== */
        .header {
            background: linear-gradient(135deg, #1a6b7c 0%, #2a9d8f 100%);
            padding: 16px 32px;
            display: flex;
            align-items: center;
            gap: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
        }
        .header-icon {
            font-size: 28px;
        }
        .header-text h1 {
            font-size: 20px;
            font-weight: 700;
            color: #fff;
            letter-spacing: 0.3px;
        }
        .header-text p {
            font-size: 12px;
            color: rgba(255,255,255,0.75);
            margin-top: 2px;
        }

        /* ===== NAVBAR ===== */
        .navbar {
            background: #155e6e;
            display: flex;
            align-items: center;
            padding: 0 32px;
            gap: 4px;
            position: relative;
            z-index: 100;
        }
        .navbar > a, .dropdown > .nav-btn {
            display: inline-block;
            padding: 13px 16px;
            color: #cef0f4;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            background: none;
            border: none;
            cursor: pointer;
            font-family: inherit;
            transition: background 0.15s, color 0.15s;
            white-space: nowrap;
        }
        .navbar > a:hover, .dropdown > .nav-btn:hover,
        .navbar > a.active, .dropdown.active > .nav-btn {
            background: rgba(255,255,255,0.1);
            color: #fff;
        }

        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: #fff;
            min-width: 210px;
            border-radius: 0 0 6px 6px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.12);
            border-top: 3px solid #2a9d8f;
            z-index: 999;
        }
        .dropdown:hover .dropdown-menu { display: block; }
        .dropdown-menu a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            font-size: 13px;
            color: #2d3748;
            text-decoration: none;
            border-bottom: 1px solid #f0f0f0;
            transition: background 0.12s;
        }
        .dropdown-menu a:last-child { border-bottom: none; }
        .dropdown-menu a:hover { background: #eaf7f7; color: #1a6b7c; }
        .dropdown-menu a .ico { font-size: 15px; width: 20px; text-align: center; }
        .nav-arrow { font-size: 10px; margin-left: 4px; opacity: 0.7; }

        /* ===== MAIN CONTENT ===== */
        .main {
            padding: 32px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Alert */
        .alert {
            padding: 12px 18px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            font-weight: 600;
        }
        .alert-success { background: #d4f5ec; color: #1a6b4a; border-left: 4px solid #2a9d8f; }
        .alert-error   { background: #fde8e8; color: #8b1c1c; border-left: 4px solid #e53e3e; }

        /* Dashboard Cards */
        .dashboard-title {
            font-size: 16px;
            font-weight: 700;
            color: #1a6b7c;
            margin-bottom: 20px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e2e8f0;
        }
        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 18px;
            margin-bottom: 36px;
        }
        .card {
            background: #fff;
            border-radius: 10px;
            padding: 22px 20px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.07);
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: #2d3748;
            border: 1px solid #e8edf2;
            transition: box-shadow 0.15s, transform 0.15s, border-color 0.15s;
        }
        .card:hover {
            box-shadow: 0 4px 14px rgba(26,107,124,0.15);
            transform: translateY(-2px);
            border-color: #2a9d8f;
        }
        .card-icon {
            font-size: 30px;
            flex-shrink: 0;
        }
        .card-info .card-label {
            font-size: 11px;
            color: #718096;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .card-info .card-title {
            font-size: 14px;
            font-weight: 700;
            color: #2d3748;
            margin-top: 3px;
        }

        /* Section label */
        .section-label {
            font-size: 11px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #a0aec0;
            margin-bottom: 12px;
            margin-top: 28px;
        }
        .section-label:first-of-type { margin-top: 0; }

        /* Footer */
        .footer {
            text-align: center;
            padding: 20px;
            font-size: 12px;
            color: #a0aec0;
            border-top: 1px solid #e2e8f0;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header">
    <div class="header-icon">🏭</div>
    <div class="header-text">
        <h1>Sistem Informasi Gudang</h1>
        <p>Manajemen Inventori & Transaksi</p>
    </div>
</div>

<!-- NAVBAR -->
<nav class="navbar">
    <a href="index.php" class="active">🏠 Home</a>

    <!-- Data Master -->
    <div class="dropdown">
        <button class="nav-btn">📦 Data Master <span class="nav-arrow">▼</span></button>
        <div class="dropdown-menu">
            <a href="gudang/index.php"><span class="ico">🏭</span> Data Gudang</a>
            <a href="barang/index.php"><span class="ico">📦</span> Data Barang</a>
            <a href="jenis/index.php"><span class="ico">🏷️</span> Data Satuan / Jenis</a>
            <a href="supplier/index.php"><span class="ico">🚚</span> Data Supplier</a>
            <a href="customer/index.php"><span class="ico">👤</span> Data Customer</a>
        </div>
    </div>

    <!-- Data Transaksi -->
    <div class="dropdown">
        <button class="nav-btn">🔄 Data Transaksi <span class="nav-arrow">▼</span></button>
        <div class="dropdown-menu">
            <a href="pembelian/index.php"><span class="ico">🛒</span> Transaksi Pembelian</a>
            <a href="penjualan/index.php"><span class="ico">💰</span> Transaksi Penjualan</a>
        </div>
    </div>

    <!-- Laporan -->
    <div class="dropdown">
        <button class="nav-btn">📊 Laporan <span class="nav-arrow">▼</span></button>
        <div class="dropdown-menu">
            <a href="laporan/penjualan.php"><span class="ico">📊</span> Laporan Penjualan</a>
        </div>
    </div>
</nav>

<!-- MAIN -->
<div class="main">

    <?php
    if (isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        if ($pesan == 'input')  echo "<div class='alert alert-success'>✅ Data berhasil ditambahkan.</div>";
        if ($pesan == 'update') echo "<div class='alert alert-success'>✅ Data berhasil diperbarui.</div>";
        if ($pesan == 'hapus')  echo "<div class='alert alert-success'>✅ Data berhasil dihapus.</div>";
        if ($pesan == 'error')  echo "<div class='alert alert-error'>❌ Terjadi kesalahan. Silakan coba lagi.</div>";
    }
    ?>

    <div class="dashboard-title">📋 Dashboard — Pilih Menu</div>

    <!-- Data Master -->
    <div class="section-label">Data Master</div>
    <div class="card-grid">
        <a class="card" href="gudang/index.php">
            <span class="card-icon">🏭</span>
            <div class="card-info">
                <div class="card-label">Master</div>
                <div class="card-title">Data Gudang</div>
            </div>
        </a>
        <a class="card" href="barang/index.php">
            <span class="card-icon">📦</span>
            <div class="card-info">
                <div class="card-label">Master</div>
                <div class="card-title">Data Barang</div>
            </div>
        </a>
        <a class="card" href="jenis/index.php">
            <span class="card-icon">🏷️</span>
            <div class="card-info">
                <div class="card-label">Master</div>
                <div class="card-title">Data Satuan / Jenis</div>
            </div>
        </a>
        <a class="card" href="supplier/index.php">
            <span class="card-icon">🚚</span>
            <div class="card-info">
                <div class="card-label">Master</div>
                <div class="card-title">Data Supplier</div>
            </div>
        </a>
        <a class="card" href="customer/index.php">
            <span class="card-icon">👤</span>
            <div class="card-info">
                <div class="card-label">Master</div>
                <div class="card-title">Data Customer</div>
            </div>
        </a>
    </div>

    <!-- Transaksi -->
    <div class="section-label">Data Transaksi</div>
    <div class="card-grid">
        <a class="card" href="pembelian/index.php">
            <span class="card-icon">🛒</span>
            <div class="card-info">
                <div class="card-label">Transaksi</div>
                <div class="card-title">Pembelian</div>
            </div>
        </a>
        <a class="card" href="penjualan/index.php">
            <span class="card-icon">💰</span>
            <div class="card-info">
                <div class="card-label">Transaksi</div>
                <div class="card-title">Penjualan</div>
            </div>
        </a>
    </div>

    <!-- Laporan -->
    <div class="section-label">Laporan</div>
    <div class="card-grid">
        <a class="card" href="laporan/penjualan.php">
            <span class="card-icon">📊</span>
            <div class="card-info">
                <div class="card-label">Laporan</div>
                <div class="card-title">Laporan Penjualan</div>
            </div>
        </a>
    </div>

</div>

<div class="footer">
    &copy; <?php echo date('Y'); ?> Sistem Informasi Gudang &mdash; Fakhran Fathur Rahman
</div>

</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Gudang — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Data Gudang</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <?php
    if (isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        if ($pesan == 'input')  echo "<p class='alert'>✅ Data berhasil ditambahkan.</p>";
        if ($pesan == 'update') echo "<p class='alert'>✅ Data berhasil diperbarui.</p>";
        if ($pesan == 'hapus')  echo "<p class='alert'>✅ Data berhasil dihapus.</p>";
    }
    ?>

    <a class="tombol" href="input.php">+ Tambah Data Gudang</a>

    <h3>Daftar Data Gudang</h3>
    <table border="1" class="table">
        <tr>
            <th>No</th>
            <th>Kode Gudang</th>
            <th>Nama Gudang</th>
            <th>Lokasi</th>
            <th>Opsi</th>
        </tr>
        <?php
        try {
            include "../koneksi.php";

            if (!$koneksi) throw new Exception("Koneksi ke database gagal.");

            $query = mysqli_query($koneksi, "SELECT * FROM tb_gudang ORDER BY id_gudang ASC");

            if (!$query) throw new Exception("Gagal mengambil data gudang.");

            $nomor = 1;
            $ada_data = false;
            while ($data = mysqli_fetch_array($query)) {
                $ada_data = true;
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo htmlspecialchars($data['kode_gudang']); ?></td>
                <td><?php echo htmlspecialchars($data['nama_gudang']); ?></td>
                <td><?php echo htmlspecialchars($data['lokasi'] ?? '-'); ?></td>
                <td>
                    <a class="edit" href="edit.php?id=<?php echo $data['id_gudang']; ?>">Edit</a> |
                    <a class="hapus" href="hapus.php?id=<?php echo $data['id_gudang']; ?>"
                       onclick="return confirm('Yakin hapus data gudang ini?')">Hapus</a>
                </td>
            </tr>
            <?php
            }

            if (!$ada_data) {
                echo "<tr><td colspan='5' style='text-align:center; color:#888; padding:16px;'>Belum ada data gudang.</td></tr>";
            }

        } catch (Exception $e) {
            echo "<tr><td colspan='5' style='color:red; text-align:center; padding:10px;'>❌ Error: " . $e->getMessage() . "</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
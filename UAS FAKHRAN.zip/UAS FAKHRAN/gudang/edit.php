<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Gudang — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Data Gudang</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Gudang</a>

    <h3>Form Edit Data Gudang</h3>

    <?php
    include '../koneksi.php';

    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<p style='color:red;'>❌ ID tidak valid.</p>";
        exit;
    }

    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = mysqli_query($koneksi, "SELECT * FROM tb_gudang WHERE id_gudang='$id'");
    $data  = mysqli_fetch_array($query);

    if (!$data) {
        echo "<p style='color:red;'>❌ Data gudang tidak ditemukan.</p>";
        exit;
    }
    ?>

    <form action="update.php" method="post">
        <input type="hidden" name="id_gudang" value="<?php echo $data['id_gudang']; ?>">
        <table>
            <tr>
                <td>Kode Gudang</td>
                <td><input type="text" name="kode_gudang" value="<?php echo htmlspecialchars($data['kode_gudang']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Nama Gudang</td>
                <td><input type="text" name="nama_gudang" value="<?php echo htmlspecialchars($data['nama_gudang']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Lokasi</td>
                <td><input type="text" name="lokasi" value="<?php echo htmlspecialchars($data['lokasi'] ?? ''); ?>" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan Perubahan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
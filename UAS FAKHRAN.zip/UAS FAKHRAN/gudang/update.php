<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_gudang   = mysqli_real_escape_string($koneksi, $_POST['id_gudang']);
    $kode_gudang = mysqli_real_escape_string($koneksi, $_POST['kode_gudang']);
    $nama_gudang = mysqli_real_escape_string($koneksi, $_POST['nama_gudang']);
    $lokasi      = mysqli_real_escape_string($koneksi, $_POST['lokasi']);

    try {
        $query = mysqli_query($koneksi, "UPDATE tb_gudang 
                                         SET kode_gudang='$kode_gudang', 
                                             nama_gudang='$nama_gudang', 
                                             lokasi='$lokasi' 
                                         WHERE id_gudang='$id_gudang'");

        if ($query) {
            header("location: index.php?pesan=update");
        } else {
            header("location: edit.php?id=$id_gudang&pesan=error");
        }

    } catch (Exception $e) {
        header("location: edit.php?id=$id_gudang&pesan=error");
    }

} else {
    header("location: index.php");
}
exit;
?>
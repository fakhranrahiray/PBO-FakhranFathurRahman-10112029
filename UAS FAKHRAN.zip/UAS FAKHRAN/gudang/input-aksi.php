<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode_gudang = mysqli_real_escape_string($koneksi, $_POST['kode_gudang']);
    $nama_gudang = mysqli_real_escape_string($koneksi, $_POST['nama_gudang']);
    $lokasi      = mysqli_real_escape_string($koneksi, $_POST['lokasi']);

    try {
        $query = mysqli_query($koneksi, "INSERT INTO tb_gudang (kode_gudang, nama_gudang, lokasi) 
                                         VALUES ('$kode_gudang', '$nama_gudang', '$lokasi')");

        if ($query) {
            header("location: index.php?pesan=input");
        } else {
            header("location: input.php?pesan=error");
        }

    } catch (Exception $e) {
        header("location: input.php?pesan=error");
    }

} else {
    header("location: input.php");
}
exit;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .filter-box { background:#f9f9f9; border:1px solid #ddd; padding:16px 20px; border-radius:6px; margin-bottom:20px; }
        .filter-box table td { padding:6px 10px; }
        .filter-box select, .filter-box input[type="date"] { padding:6px 10px; border:1px solid #ccc; border-radius:4px; }
        @media print {
            .navbar, .judul, .filter-box, .tombol, .no-print { display: none !important; }
            body { margin: 0; }
            .container { padding: 0; }
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Laporan Penjualan</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <?php
    include "../koneksi.php";

    // Filter default: bulan ini
    $dari    = isset($_GET['dari'])        ? $_GET['dari']        : date('Y-m-01');
    $sampai  = isset($_GET['sampai'])      ? $_GET['sampai']      : date('Y-m-d');
    $id_cust = isset($_GET['id_customer']) ? $_GET['id_customer'] : '';

    $dari_esc   = mysqli_real_escape_string($koneksi, $dari);
    $sampai_esc = mysqli_real_escape_string($koneksi, $sampai);
    $cust_esc   = mysqli_real_escape_string($koneksi, $id_cust);
    ?>

    <!-- FILTER -->
    <div class="filter-box no-print">
        <form method="GET" action="">
            <table>
                <tr>
                    <td>Customer</td>
                    <td>
                        <select name="id_customer">
                            <option value="">-- Semua Customer --</option>
                            <?php
                            $qCust = mysqli_query($koneksi, "SELECT * FROM tb_customer ORDER BY nama_customer ASC");
                            while ($c = mysqli_fetch_array($qCust)):
                            ?>
                            <option value="<?php echo $c['id_customer']; ?>" <?php echo $id_cust == $c['id_customer'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($c['nama_customer']); ?>
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Dari Tanggal</td>
                    <td><input type="date" name="dari" value="<?php echo htmlspecialchars($dari); ?>"></td>
                </tr>
                <tr>
                    <td>Sampai Tanggal</td>
                    <td><input type="date" name="sampai" value="<?php echo htmlspecialchars($sampai); ?>"></td>
                </tr>
                <tr>
                    <td></td>
                    <td style="padding-top:10px;">
                        <button type="submit" class="tombol">🔍 Tampilkan</button>
                        <a href="penjualan.php" class="tombol" style="background:#888;">Reset</a>
                    </td>
                </tr>
            </table>
        </form>
    </div>

    <?php
    // Bangun query laporan
    $whereCustomer = $cust_esc ? "AND p.id_customer = '$cust_esc'" : "";

    $query = mysqli_query($koneksi, "
        SELECT
            p.no_penjualan,
            p.tanggal_penjualan,
            c.nama_customer,
            b.nama_barang,
            j.jenis AS satuan,
            dp.jumlah_barang,
            dp.harga_barang,
            dp.total_harga
        FROM tb_penjualan p
        LEFT JOIN tb_customer c    ON p.id_customer = c.id_customer
        LEFT JOIN detail_penjualan dp ON p.no_penjualan = dp.no_penjualan
        LEFT JOIN tb_barang b      ON dp.kd_barang = b.kd_barang
        LEFT JOIN tb_jenis j       ON dp.kode_jenis = j.kode_jenis
        WHERE p.tanggal_penjualan BETWEEN '$dari_esc' AND '$sampai_esc'
        $whereCustomer
        ORDER BY p.tanggal_penjualan ASC, p.no_penjualan ASC, dp.no_item ASC
    ");
    ?>

    <!-- JUDUL CETAK -->
    <div style="text-align:center; margin-bottom:10px;">
        <h3 style="margin:0;">LAPORAN PENJUALAN</h3>
        <p style="margin:4px 0; font-size:13px;">
            Periode: <?php echo date('d/m/Y', strtotime($dari)); ?> s/d <?php echo date('d/m/Y', strtotime($sampai)); ?>
            <?php if ($id_cust): ?>
                <?php
                $qNamaCust = mysqli_query($koneksi, "SELECT nama_customer FROM tb_customer WHERE id_customer = '$cust_esc'");
                $namaCust  = mysqli_fetch_array($qNamaCust);
                echo ' | Customer: ' . htmlspecialchars($namaCust['nama_customer'] ?? '-');
                ?>
            <?php else: ?>
                | Customer: Semua
            <?php endif; ?>
        </p>
    </div>

    <table border="1" class="table">
        <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>No. Penjualan</th>
            <th>Customer</th>
            <th>Nama Barang</th>
            <th>Satuan</th>
            <th>Qty</th>
            <th>Harga Satuan</th>
            <th>Subtotal</th>
        </tr>
        <?php
        $nomor      = 1;
        $grandTotal = 0;
        $ada_data   = false;

        while ($row = mysqli_fetch_array($query)):
            $ada_data    = true;
            $grandTotal += $row['total_harga'];
        ?>
        <tr>
            <td><?php echo $nomor++; ?></td>
            <td><?php echo htmlspecialchars($row['tanggal_penjualan']); ?></td>
            <td><?php echo htmlspecialchars($row['no_penjualan']); ?></td>
            <td><?php echo htmlspecialchars($row['nama_customer']); ?></td>
            <td><?php echo htmlspecialchars($row['nama_barang']); ?></td>
            <td><?php echo htmlspecialchars($row['satuan']); ?></td>
            <td><?php echo htmlspecialchars($row['jumlah_barang']); ?></td>
            <td>Rp <?php echo number_format($row['harga_barang'], 0, ',', '.'); ?></td>
            <td>Rp <?php echo number_format($row['total_harga'], 0, ',', '.'); ?></td>
        </tr>
        <?php endwhile; ?>

        <?php if (!$ada_data): ?>
        <tr>
            <td colspan="9" style="text-align:center; color:#888; padding:16px;">
                Tidak ada data penjualan untuk periode ini.
            </td>
        </tr>
        <?php else: ?>
        <tr>
            <td colspan="8" style="text-align:right; font-weight:bold; padding:8px;">TOTAL</td>
            <td style="font-weight:bold; padding:8px;">Rp <?php echo number_format($grandTotal, 0, ',', '.'); ?></td>
        </tr>
        <?php endif; ?>
    </table>

    <br>
    <button class="tombol no-print" onclick="window.print()">🖨️ Cetak / Simpan PDF</button>

</div>

</body>
</html>
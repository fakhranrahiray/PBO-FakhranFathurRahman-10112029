<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: index.php");
    exit;
}

$kd_barang = mysqli_real_escape_string($koneksi, $_GET['id']);

try {
    $query = mysqli_query($koneksi, "DELETE FROM tb_barang WHERE kd_barang='$kd_barang'");

    if ($query) {
        header("location: index.php?pesan=hapus");
    } else {
        header("location: index.php?pesan=error");
    }

} catch (Exception $e) {
    header("location: index.php?pesan=error");
}
exit;
?>
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kd_barang    = mysqli_real_escape_string($koneksi, $_POST['kd_barang']);
    $nama_barang  = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $kode_jenis   = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
    $stok         = mysqli_real_escape_string($koneksi, $_POST['stok']);
    $harga_beli   = mysqli_real_escape_string($koneksi, $_POST['harga_beli']);
    $harga_jual   = mysqli_real_escape_string($koneksi, $_POST['harga_jual']);
    $gambar_produk = mysqli_real_escape_string($koneksi, $_POST['gambar_produk']);

    try {
        $query = mysqli_query($koneksi, "INSERT INTO tb_barang (kd_barang, kode_jenis, nama_barang, stok, harga_beli, harga_jual, gambar_produk) 
                                         VALUES ('$kd_barang', '$kode_jenis', '$nama_barang', '$stok', '$harga_beli', '$harga_jual', '$gambar_produk')");

        if ($query) {
            header("location: index.php?pesan=input");
        } else {
            header("location: input.php?pesan=error");
        }

    } catch (Exception $e) {
        header("location: input.php?pesan=error");
    }

} else {
    header("location: input.php");
}
exit;
?>
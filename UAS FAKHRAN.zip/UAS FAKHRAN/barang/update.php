<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kd_barang     = mysqli_real_escape_string($koneksi, $_POST['kd_barang']);
    $nama_barang   = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $kode_jenis    = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
    $stok          = mysqli_real_escape_string($koneksi, $_POST['stok']);
    $harga_beli    = mysqli_real_escape_string($koneksi, $_POST['harga_beli']);
    $harga_jual    = mysqli_real_escape_string($koneksi, $_POST['harga_jual']);
    $gambar_produk = mysqli_real_escape_string($koneksi, $_POST['gambar_produk']);

    try {
        $query = mysqli_query($koneksi, "UPDATE tb_barang 
                                         SET nama_barang='$nama_barang', 
                                             kode_jenis='$kode_jenis', 
                                             stok='$stok', 
                                             harga_beli='$harga_beli', 
                                             harga_jual='$harga_jual', 
                                             gambar_produk='$gambar_produk' 
                                         WHERE kd_barang='$kd_barang'");

        if ($query) {
            header("location: index.php?pesan=update");
        } else {
            header("location: edit.php?id=$kd_barang&pesan=error");
        }

    } catch (Exception $e) {
        header("location: edit.php?id=$kd_barang&pesan=error");
    }

} else {
    header("location: index.php");
}
exit;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Barang — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Tambah Data Barang</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Barang</a>

    <h3>Form Tambah Data Barang</h3>

    <form action="input-aksi.php" method="post">
        <table>
            <tr>
                <td>Kode Barang</td>
                <td><input type="text" name="kd_barang" placeholder="Contoh: BRG-001" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Nama Barang</td>
                <td><input type="text" name="nama_barang" placeholder="Contoh: Beras 5kg" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Jenis / Satuan</td>
                <td>
                    <select name="kode_jenis" required style="padding:6px; width:250px;">
                        <option value="">-- Pilih Jenis --</option>
                        <?php
                        include '../koneksi.php';
                        $q_jenis = mysqli_query($koneksi, "SELECT * FROM tb_jenis ORDER BY jenis ASC");
                        while ($j = mysqli_fetch_array($q_jenis)) {
                            echo "<option value='" . htmlspecialchars($j['kode_jenis']) . "'>" 
                                . htmlspecialchars($j['jenis']) . " / " . htmlspecialchars($j['satuan']) 
                                . "</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Stok</td>
                <td><input type="number" name="stok" placeholder="Contoh: 100" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Harga Beli</td>
                <td><input type="number" name="harga_beli" placeholder="Contoh: 50000" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Harga Jual</td>
                <td><input type="number" name="harga_jual" placeholder="Contoh: 65000" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Gambar Produk (URL)</td>
                <td><input type="text" name="gambar_produk" placeholder="Contoh: gambar/beras.jpg" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
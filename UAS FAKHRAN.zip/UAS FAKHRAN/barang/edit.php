<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Barang — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Data Barang</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Barang</a>

    <h3>Form Edit Data Barang</h3>

    <?php
    include '../koneksi.php';

    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<p style='color:red;'>❌ ID tidak valid.</p>";
        exit;
    }

    $id    = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = mysqli_query($koneksi, "SELECT * FROM tb_barang WHERE kd_barang='$id'");
    $data  = mysqli_fetch_array($query);

    if (!$data) {
        echo "<p style='color:red;'>❌ Data barang tidak ditemukan.</p>";
        exit;
    }
    ?>

    <form action="update.php" method="post">
        <input type="hidden" name="kd_barang" value="<?php echo htmlspecialchars($data['kd_barang']); ?>">
        <table>
            <tr>
                <td>Kode Barang</td>
                <td><input type="text" value="<?php echo htmlspecialchars($data['kd_barang']); ?>" disabled style="padding:6px; width:250px; background:#f0f0f0;"></td>
            </tr>
            <tr>
                <td>Nama Barang</td>
                <td><input type="text" name="nama_barang" value="<?php echo htmlspecialchars($data['nama_barang']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Jenis / Satuan</td>
                <td>
                    <select name="kode_jenis" required style="padding:6px; width:250px;">
                        <option value="">-- Pilih Jenis --</option>
                        <?php
                        $q_jenis = mysqli_query($koneksi, "SELECT * FROM tb_jenis ORDER BY jenis ASC");
                        while ($j = mysqli_fetch_array($q_jenis)) {
                            $selected = ($j['kode_jenis'] == $data['kode_jenis']) ? 'selected' : '';
                            echo "<option value='" . htmlspecialchars($j['kode_jenis']) . "' $selected>" 
                                . htmlspecialchars($j['jenis']) . " / " . htmlspecialchars($j['satuan']) 
                                . "</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Stok</td>
                <td><input type="number" name="stok" value="<?php echo $data['stok']; ?>" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Harga Beli</td>
                <td><input type="number" name="harga_beli" value="<?php echo $data['harga_beli']; ?>" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Harga Jual</td>
                <td><input type="number" name="harga_jual" value="<?php echo $data['harga_jual']; ?>" min="0" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Gambar Produk (URL)</td>
                <td><input type="text" name="gambar_produk" value="<?php echo htmlspecialchars($data['gambar_produk'] ?? ''); ?>" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan Perubahan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
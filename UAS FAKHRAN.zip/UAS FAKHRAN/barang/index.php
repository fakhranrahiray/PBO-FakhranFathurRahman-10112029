<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Barang — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Data Barang</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <?php
    if (isset($_GET['pesan'])) {
        $pesan = $_GET['pesan'];
        if ($pesan == 'input')  echo "<p class='alert'>✅ Data berhasil ditambahkan.</p>";
        if ($pesan == 'update') echo "<p class='alert'>✅ Data berhasil diperbarui.</p>";
        if ($pesan == 'hapus')  echo "<p class='alert'>✅ Data berhasil dihapus.</p>";
        if ($pesan == 'error')  echo "<p class='alert' style='color:red;'>❌ Terjadi kesalahan. Silakan coba lagi.</p>";
    }
    ?>

    <a class="tombol" href="input.php">+ Tambah Data Barang</a>

    <h3>Daftar Data Barang</h3>
    <table border="1" class="table">
        <tr>
            <th>No</th>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Jenis / Satuan</th>
            <th>Stok</th>
            <th>Harga Beli</th>
            <th>Harga Jual</th>
            <th>Gambar</th>
            <th>Opsi</th>
        </tr>
        <?php
        try {
            include "../koneksi.php";

            if (!$koneksi) throw new Exception("Koneksi ke database gagal.");

            $query = mysqli_query($koneksi, "SELECT b.*, j.jenis, j.satuan 
                                             FROM tb_barang b 
                                             LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis 
                                             ORDER BY b.kd_barang ASC");

            if (!$query) throw new Exception("Gagal mengambil data barang.");

            $nomor = 1;
            $ada_data = false;
            while ($data = mysqli_fetch_array($query)) {
                $ada_data = true;
            ?>
            <tr>
                <td><?php echo $nomor++; ?></td>
                <td><?php echo htmlspecialchars($data['kd_barang']); ?></td>
                <td><?php echo htmlspecialchars($data['nama_barang']); ?></td>
                <td><?php echo htmlspecialchars($data['jenis'] ?? '-'); ?> / <?php echo htmlspecialchars($data['satuan'] ?? '-'); ?></td>
                <td><?php echo $data['stok']; ?></td>
                <td>Rp <?php echo number_format($data['harga_beli'], 0, ',', '.'); ?></td>
                <td>Rp <?php echo number_format($data['harga_jual'], 0, ',', '.'); ?></td>
                <td style="text-align:center;">
                    <?php if (!empty($data['gambar_produk'])): ?>
                        <img src="../gambar/<?php echo htmlspecialchars($data['gambar_produk']); ?>"
                             width="60" height="45"
                             style="object-fit:cover; border-radius:4px; border:1px solid #ddd;"
                             alt="<?php echo htmlspecialchars($data['nama_barang']); ?>">
                    <?php else: ?>
                        <span style="color:#aaa; font-size:12px;">— Belum ada —</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a class="edit" href="edit.php?id=<?php echo $data['kd_barang']; ?>">✏️ Edit</a> &nbsp;|&nbsp;
                    <a class="hapus" href="hapus.php?id=<?php echo $data['kd_barang']; ?>"
                       onclick="return confirm('Yakin hapus data barang ini?')">🗑️ Hapus</a>
                </td>
            </tr>
            <?php
            }

            if (!$ada_data) {
                echo "<tr><td colspan='9' style='text-align:center; color:#888; padding:16px;'>Belum ada data barang.</td></tr>";
            }

        } catch (Exception $e) {
            echo "<tr><td colspan='9' style='color:red; text-align:center; padding:10px;'>❌ Error: " . $e->getMessage() . "</td></tr>";
        }
        ?>
    </table>
</div>

</body>
</html>
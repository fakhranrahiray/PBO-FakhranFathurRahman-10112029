<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_supplier      = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
    $nama_supplier    = mysqli_real_escape_string($koneksi, $_POST['nama_supplier']);
    $alamat_supplier  = mysqli_real_escape_string($koneksi, $_POST['alamat_supplier']);
    $telepon_supplier = mysqli_real_escape_string($koneksi, $_POST['telepon_supplier']);
    $email_supplier   = mysqli_real_escape_string($koneksi, $_POST['email_supplier']);
    $pass_supplier    = mysqli_real_escape_string($koneksi, $_POST['pass_supplier']);

    try {
        $query = mysqli_query($koneksi, "INSERT INTO tb_supplier (id_supplier, nama_supplier, alamat_supplier, telepon_supplier, email_supplier, pass_supplier) 
                                         VALUES ('$id_supplier', '$nama_supplier', '$alamat_supplier', '$telepon_supplier', '$email_supplier', '$pass_supplier')");

        if ($query) {
            header("location: index.php?pesan=input");
        } else {
            header("location: input.php?pesan=error");
        }

    } catch (Exception $e) {
        header("location: input.php?pesan=error");
    }

} else {
    header("location: input.php");
}
exit;
?>
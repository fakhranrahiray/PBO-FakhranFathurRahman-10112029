<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_supplier      = mysqli_real_escape_string($koneksi, $_POST['id_supplier']);
    $nama_supplier    = mysqli_real_escape_string($koneksi, $_POST['nama_supplier']);
    $alamat_supplier  = mysqli_real_escape_string($koneksi, $_POST['alamat_supplier']);
    $telepon_supplier = mysqli_real_escape_string($koneksi, $_POST['telepon_supplier']);
    $email_supplier   = mysqli_real_escape_string($koneksi, $_POST['email_supplier']);
    $pass_supplier    = mysqli_real_escape_string($koneksi, $_POST['pass_supplier']);

    try {
        // Cek apakah password diisi atau tidak
        if (!empty($pass_supplier)) {
            // Update semua field termasuk password
            $query = mysqli_query($koneksi, "UPDATE tb_supplier 
                                             SET nama_supplier='$nama_supplier', 
                                                 alamat_supplier='$alamat_supplier', 
                                                 telepon_supplier='$telepon_supplier', 
                                                 email_supplier='$email_supplier', 
                                                 pass_supplier='$pass_supplier' 
                                             WHERE id_supplier='$id_supplier'");
        } else {
            // Update semua field kecuali password
            $query = mysqli_query($koneksi, "UPDATE tb_supplier 
                                             SET nama_supplier='$nama_supplier', 
                                                 alamat_supplier='$alamat_supplier', 
                                                 telepon_supplier='$telepon_supplier', 
                                                 email_supplier='$email_supplier' 
                                             WHERE id_supplier='$id_supplier'");
        }

        if ($query) {
            header("location: index.php?pesan=update");
        } else {
            header("location: edit.php?id=$id_supplier&pesan=error");
        }

    } catch (Exception $e) {
        header("location: edit.php?id=$id_supplier&pesan=error");
    }

} else {
    header("location: index.php");
}
exit;
?>
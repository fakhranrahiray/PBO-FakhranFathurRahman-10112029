<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: index.php");
    exit;
}

$id_supplier = mysqli_real_escape_string($koneksi, $_GET['id']);

try {
    $query = mysqli_query($koneksi, "DELETE FROM tb_supplier WHERE id_supplier='$id_supplier'");

    if ($query) {
        header("location: index.php?pesan=hapus");
    } else {
        header("location: index.php?pesan=error");
    }

} catch (Exception $e) {
    header("location: index.php?pesan=error");
}
exit;
?>
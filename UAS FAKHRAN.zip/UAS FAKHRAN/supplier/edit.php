<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Supplier — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Data Supplier</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Supplier</a>

    <h3>Form Edit Data Supplier</h3>

    <?php
    include '../koneksi.php';

    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<p style='color:red;'>❌ ID tidak valid.</p>";
        exit;
    }

    $id    = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = mysqli_query($koneksi, "SELECT * FROM tb_supplier WHERE id_supplier='$id'");
    $data  = mysqli_fetch_array($query);

    if (!$data) {
        echo "<p style='color:red;'>❌ Data supplier tidak ditemukan.</p>";
        exit;
    }
    ?>

    <form action="update.php" method="post">
        <input type="hidden" name="id_supplier" value="<?php echo htmlspecialchars($data['id_supplier']); ?>">
        <table>
            <tr>
                <td>ID Supplier</td>
                <td><input type="text" value="<?php echo htmlspecialchars($data['id_supplier']); ?>" disabled style="padding:6px; width:250px; background:#f0f0f0;"></td>
            </tr>
            <tr>
                <td>Nama Supplier</td>
                <td><input type="text" name="nama_supplier" value="<?php echo htmlspecialchars($data['nama_supplier']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><textarea name="alamat_supplier" rows="3" style="padding:6px; width:250px;"><?php echo htmlspecialchars($data['alamat_supplier']); ?></textarea></td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon_supplier" value="<?php echo htmlspecialchars($data['telepon_supplier']); ?>" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email_supplier" value="<?php echo htmlspecialchars($data['email_supplier']); ?>" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Password Baru</td>
                <td>
                    <input type="password" name="pass_supplier" placeholder="Kosongkan jika tidak ingin mengubah" style="padding:6px; width:250px;">
                    <br><small style="color:#888;">*Kosongkan jika tidak ingin mengubah password</small>
                </td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan Perubahan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Supplier — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Tambah Data Supplier</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Supplier</a>

    <h3>Form Tambah Data Supplier</h3>

    <form action="input-aksi.php" method="post">
        <table>
            <tr>
                <td>ID Supplier</td>
                <td><input type="text" name="id_supplier" placeholder="Contoh: SUP-001" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Nama Supplier</td>
                <td><input type="text" name="nama_supplier" placeholder="Contoh: PT. Maju Jaya" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><textarea name="alamat_supplier" placeholder="Contoh: Jl. Sudirman No. 10, Jakarta" rows="3" style="padding:6px; width:250px;"></textarea></td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon_supplier" placeholder="Contoh: 08123456789" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email_supplier" placeholder="Contoh: supplier@email.com" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="pass_supplier" placeholder="Password supplier" style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $no = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Kembalikan stok dulu sebelum hapus (tambah balik stok)
    $qDetail = mysqli_query($koneksi, "SELECT kd_barang, jumlah_barang FROM detail_penjualan WHERE no_penjualan = '$no'");
    while ($d = mysqli_fetch_array($qDetail)) {
        $kd  = mysqli_real_escape_string($koneksi, $d['kd_barang']);
        $jml = (int)$d['jumlah_barang'];
        mysqli_query($koneksi, "UPDATE tb_barang SET stok = stok + $jml WHERE kd_barang = '$kd'");
    }

    // Hapus detail penjualan dulu
    mysqli_query($koneksi, "DELETE FROM detail_penjualan WHERE no_penjualan = '$no'");

    // Hapus header penjualan
    $query = "DELETE FROM tb_penjualan WHERE no_penjualan = '$no'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?pesan=hapus");
    } else {
        header("Location: index.php?pesan=error");
    }
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
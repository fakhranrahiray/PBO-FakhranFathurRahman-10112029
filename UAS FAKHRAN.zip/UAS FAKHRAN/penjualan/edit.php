<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Penjualan — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .detail-table { width:100%; border-collapse:collapse; margin-top:10px; }
        .detail-table th, .detail-table td { border:1px solid #ccc; padding:8px; text-align:center; }
        .detail-table th { background:#f0f0f0; }
        #total-info { margin-top:12px; font-size:15px; font-weight:bold; }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Transaksi Penjualan</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <a class="tombol" href="index.php">← Kembali</a>

    <h3>Form Edit Penjualan</h3>

    <?php
    include "../koneksi.php";
    $no = mysqli_real_escape_string($koneksi, $_GET['id']);

    // Ambil header penjualan
    $qHeader = mysqli_query($koneksi, "SELECT * FROM tb_penjualan WHERE no_penjualan = '$no'");
    $header  = mysqli_fetch_array($qHeader);

    if (!$header) {
        echo "<p style='color:red;'>❌ Data penjualan tidak ditemukan.</p>";
    } else {

    // Ambil detail penjualan
    $qDetail = mysqli_query($koneksi, "SELECT * FROM detail_penjualan WHERE no_penjualan = '$no' ORDER BY no_item ASC");

    // Ambil semua barang
    $qBarang = mysqli_query($koneksi, "
        SELECT b.kd_barang, b.nama_barang, b.kode_jenis, b.harga_jual, b.stok, j.jenis
        FROM tb_barang b
        LEFT JOIN tb_jenis j ON b.kode_jenis = j.kode_jenis
        ORDER BY b.nama_barang ASC
    ");
    $listBarang = [];
    while ($b = mysqli_fetch_array($qBarang)) {
        $listBarang[] = $b;
    }

    // Ambil semua customer
    $qCust = mysqli_query($koneksi, "SELECT * FROM tb_customer ORDER BY nama_customer ASC");
    ?>

    <form action="update.php" method="POST" id="formEdit">
        <input type="hidden" name="no_penjualan_lama" value="<?php echo htmlspecialchars($header['no_penjualan']); ?>">

        <table class="form-table">
            <tr>
                <td>No. Penjualan</td>
                <td><input type="text" name="no_penjualan" class="input-form"
                           value="<?php echo htmlspecialchars($header['no_penjualan']); ?>" required></td>
            </tr>
            <tr>
                <td>Tanggal Penjualan</td>
                <td><input type="date" name="tanggal_penjualan" class="input-form"
                           value="<?php echo htmlspecialchars($header['tanggal_penjualan']); ?>" required></td>
            </tr>
            <tr>
                <td>Customer</td>
                <td>
                    <select name="id_customer" class="input-form" required>
                        <option value="">-- Pilih Customer --</option>
                        <?php while ($c = mysqli_fetch_array($qCust)): ?>
                        <option value="<?php echo $c['id_customer']; ?>"
                            <?php echo $header['id_customer'] == $c['id_customer'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($c['nama_customer']); ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </td>
            </tr>
        </table>

        <hr style="margin:20px 0;">
        <h4>📋 Detail Barang</h4>

        <table class="detail-table" id="tabelDetail">
            <thead>
                <tr>
                    <th>Barang</th>
                    <th>Jenis</th>
                    <th>Stok</th>
                    <th>Jumlah</th>
                    <th>Harga Jual</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="bodyDetail"></tbody>
        </table>

        <br>
        <button type="button" class="tombol" style="background:#555;" onclick="tambahBaris()">+ Tambah Barang</button>

        <div id="total-info">
            Total Barang: <span id="totalBarang">0</span> item &nbsp;|&nbsp;
            Total Harga: Rp <span id="totalHarga">0</span>
        </div>

        <input type="hidden" name="total_barangall" id="hiddenTotalBarang" value="0">
        <input type="hidden" name="total_hargaall"  id="hiddenTotalHarga"  value="0">

        <br>
        <button type="submit" class="tombol">💾 Update Penjualan</button>
        <a href="index.php" class="tombol" style="background:#888;">Batal</a>
    </form>

    <?php
    $detailExisting = [];
    while ($d = mysqli_fetch_array($qDetail)) {
        $detailExisting[] = $d;
    }
    ?>

    <script>
    const listBarang = [
        <?php foreach ($listBarang as $b): ?>
        {kd: '<?php echo $b['kd_barang']; ?>', nama: '<?php echo addslashes($b['nama_barang']); ?>', kode_jenis: '<?php echo $b['kode_jenis']; ?>', namaJenis: '<?php echo addslashes($b['jenis']); ?>', harga: <?php echo $b['harga_jual']; ?>, stok: <?php echo $b['stok']; ?>},
        <?php endforeach; ?>
    ];

    const detailExisting = <?php echo json_encode($detailExisting); ?>;

    let noItem = 0;

    function tambahBaris(kdBarang = '', kodeJenis = '', namaJenis = '', jumlah = 1, harga = 0, stok = '-') {
        noItem++;
        const tbody = document.getElementById('bodyDetail');
        const tr    = document.createElement('tr');
        tr.id = 'baris-' + noItem;

        let opsiBarang = '<option value="">-- Pilih Barang --</option>';
        listBarang.forEach(function(b) {
            const sel = b.kd === kdBarang ? 'selected' : '';
            opsiBarang += `<option value="${b.kd}" data-jenis="${b.kode_jenis}" data-namajenis="${b.namaJenis}" data-harga="${b.harga}" data-stok="${b.stok}" ${sel}>${b.nama}</option>`;
        });

        tr.innerHTML = `
            <td>
                <select name="kd_barang[]" class="input-form" onchange="updateBaris(${noItem})" required>
                    ${opsiBarang}
                </select>
                <input type="hidden" name="kode_jenis[]" id="jenis-${noItem}" value="${kodeJenis}">
            </td>
            <td id="nama-jenis-${noItem}">${namaJenis || '-'}</td>
            <td id="stok-${noItem}">${stok}</td>
            <td><input type="number" name="jumlah_barang[]" id="jumlah-${noItem}" class="input-form" min="1" value="${jumlah}" oninput="hitungSubtotal(${noItem})" required></td>
            <td><input type="number" name="harga_barang[]"  id="harga-${noItem}"  class="input-form" min="0" value="${harga}"  oninput="hitungSubtotal(${noItem})" required></td>
            <td id="subtotal-${noItem}">Rp 0</td>
            <td><button type="button" class="tombol" style="background:#c0392b; padding:4px 10px;" onclick="hapusBaris(${noItem})">Hapus</button></td>
        `;
        tbody.appendChild(tr);
        hitungSubtotal(noItem);
    }

    function updateBaris(n) {
        const select = document.querySelector(`#baris-${n} select[name="kd_barang[]"]`);
        const opt    = select.options[select.selectedIndex];
        document.getElementById(`jenis-${n}`).value            = opt.dataset.jenis     || '';
        document.getElementById(`nama-jenis-${n}`).textContent = opt.dataset.namajenis || '-';
        document.getElementById(`stok-${n}`).textContent       = opt.dataset.stok      || '-';
        document.getElementById(`harga-${n}`).value            = opt.dataset.harga     || 0;
        hitungSubtotal(n);
    }

    function hitungSubtotal(n) {
        const jumlah = parseInt(document.getElementById(`jumlah-${n}`).value) || 0;
        const harga  = parseInt(document.getElementById(`harga-${n}`).value)  || 0;
        document.getElementById(`subtotal-${n}`).textContent = 'Rp ' + (jumlah * harga).toLocaleString('id-ID');
        updateTotal();
    }

    function hapusBaris(n) {
        document.getElementById('baris-' + n).remove();
        updateTotal();
    }

    function updateTotal() {
        let totalBarang = 0, totalHarga = 0;
        const jumlahInputs = document.querySelectorAll('input[name="jumlah_barang[]"]');
        const hargaInputs  = document.querySelectorAll('input[name="harga_barang[]"]');
        jumlahInputs.forEach(function(el, i) {
            const jml = parseInt(el.value) || 0;
            const hrg = parseInt(hargaInputs[i].value) || 0;
            totalBarang += jml;
            totalHarga  += jml * hrg;
        });
        document.getElementById('totalBarang').textContent = totalBarang;
        document.getElementById('totalHarga').textContent  = totalHarga.toLocaleString('id-ID');
        document.getElementById('hiddenTotalBarang').value = totalBarang;
        document.getElementById('hiddenTotalHarga').value  = totalHarga;
    }

    // Load detail existing
    detailExisting.forEach(function(d) {
        const barang = listBarang.find(b => b.kd === d.kd_barang);
        tambahBaris(d.kd_barang, d.kode_jenis, barang ? barang.namaJenis : '', d.jumlah_barang, d.harga_barang, barang ? barang.stok : '-');
    });

    if (detailExisting.length === 0) tambahBaris();
    </script>

    <?php } ?>
</div>

</body>
</html>
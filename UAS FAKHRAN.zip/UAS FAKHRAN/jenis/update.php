<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode_jenis = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
    $jenis      = mysqli_real_escape_string($koneksi, $_POST['jenis']);
    $satuan     = mysqli_real_escape_string($koneksi, $_POST['satuan']);

    try {
        $query = mysqli_query($koneksi, "UPDATE tb_jenis 
                                         SET jenis='$jenis', 
                                             satuan='$satuan' 
                                         WHERE kode_jenis='$kode_jenis'");

        if ($query) {
            header("location: index.php?pesan=update");
        } else {
            header("location: edit.php?id=$kode_jenis&pesan=error");
        }

    } catch (Exception $e) {
        header("location: edit.php?id=$kode_jenis&pesan=error");
    }

} else {
    header("location: index.php");
}
exit;
?>
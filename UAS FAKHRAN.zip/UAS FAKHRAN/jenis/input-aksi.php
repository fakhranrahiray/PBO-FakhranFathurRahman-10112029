<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kode_jenis = mysqli_real_escape_string($koneksi, $_POST['kode_jenis']);
    $jenis      = mysqli_real_escape_string($koneksi, $_POST['jenis']);
    $satuan     = mysqli_real_escape_string($koneksi, $_POST['satuan']);

    try {
        $query = mysqli_query($koneksi, "INSERT INTO tb_jenis (kode_jenis, jenis, satuan) 
                                         VALUES ('$kode_jenis', '$jenis', '$satuan')");

        if ($query) {
            header("location: index.php?pesan=input");
        } else {
            header("location: input.php?pesan=error");
        }

    } catch (Exception $e) {
        header("location: input.php?pesan=error");
    }

} else {
    header("location: input.php");
}
exit;
?>
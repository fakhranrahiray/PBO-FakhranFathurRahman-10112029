<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

include '../koneksi.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("location: index.php");
    exit;
}

$kode_jenis = mysqli_real_escape_string($koneksi, $_GET['id']);

try {
    $query = mysqli_query($koneksi, "DELETE FROM tb_jenis WHERE kode_jenis='$kode_jenis'");

    if ($query) {
        header("location: index.php?pesan=hapus");
    } else {
        header("location: index.php?pesan=error");
    }

} catch (Exception $e) {
    header("location: index.php?pesan=error");
}
exit;
?>
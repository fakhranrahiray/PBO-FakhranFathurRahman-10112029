<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Jenis — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Data Satuan / Jenis</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">
    <a class="tombol" href="index.php">← Kembali ke Daftar Jenis</a>

    <h3>Form Edit Data Satuan / Jenis</h3>

    <?php
    include '../koneksi.php';

    if (!isset($_GET['id']) || empty($_GET['id'])) {
        echo "<p style='color:red;'>❌ ID tidak valid.</p>";
        exit;
    }

    $id    = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = mysqli_query($koneksi, "SELECT * FROM tb_jenis WHERE kode_jenis='$id'");
    $data  = mysqli_fetch_array($query);

    if (!$data) {
        echo "<p style='color:red;'>❌ Data jenis tidak ditemukan.</p>";
        exit;
    }
    ?>

    <form action="update.php" method="post">
        <input type="hidden" name="kode_jenis" value="<?php echo htmlspecialchars($data['kode_jenis']); ?>">
        <table>
            <tr>
                <td>Kode Jenis</td>
                <td><input type="text" value="<?php echo htmlspecialchars($data['kode_jenis']); ?>" disabled style="padding:6px; width:250px; background:#f0f0f0;"></td>
            </tr>
            <tr>
                <td>Jenis</td>
                <td><input type="text" name="jenis" value="<?php echo htmlspecialchars($data['jenis']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td>Satuan</td>
                <td><input type="text" name="satuan" value="<?php echo htmlspecialchars($data['satuan']); ?>" required style="padding:6px; width:250px;"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <input type="submit" value="💾 Simpan Perubahan" style="padding:7px 20px; background:#1a6b7c; color:#fff; border:none; border-radius:4px; cursor:pointer; font-size:13px;">
                    <a href="index.php" style="margin-left:10px; font-size:13px; color:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>
</div>

</body>
</html>
<?php
// Aktifkan mode pelaporan error agar mysqli melempar Exception saat gagal
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$host     = "localhost";
$username = "root";
$password = "";
$database = "db_inventoryy";

try {
    $koneksi = mysqli_connect($host, $username, $password, $database);
    mysqli_set_charset($koneksi, "utf8mb4");

} catch (mysqli_sql_exception $e) {
    echo "<div style='font-family:Arial,sans-serif; color:red; padding:20px; border:1px solid red; background:#fff0f0; margin:20px;'>";
    echo "<h3>❌ Gagal Terhubung ke Database!</h3>";
    echo "<p>Pesan: " . $e->getMessage() . "</p>";
    echo "<p>Pastikan MySQL sudah berjalan dan database <strong>db_inventory</strong> sudah dibuat.</p>";
    echo "</div>";
    $koneksi = false;
}
?>


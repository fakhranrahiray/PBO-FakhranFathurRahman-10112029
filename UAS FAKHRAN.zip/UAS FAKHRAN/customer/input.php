<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Customer — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Tambah Data Customer</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <a class="tombol" href="index.php">← Kembali</a>

    <h3>Form Tambah Customer</h3>
    <form action="input-aksi.php" method="POST">
        <table class="form-table">
            <tr>
                <td>ID Customer</td>
                <td><input type="text" name="id_customer" class="input-form" placeholder="Contoh: CST001" required></td>
            </tr>
            <tr>
                <td>Nama Customer</td>
                <td><input type="text" name="nama_customer" class="input-form" placeholder="Nama lengkap customer" required></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>
                    <select name="jenis_kelamin" class="input-form" required>
                        <option value="">-- Pilih Jenis Kelamin --</option>
                        <option value="Laki-laki">Laki-laki</option>
                        <option value="Perempuan">Perempuan</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><textarea name="alamat_customer" class="input-form" rows="3" placeholder="Alamat lengkap" required></textarea></td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon_customer" class="input-form" placeholder="Nomor telepon" required></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email_customer" class="input-form" placeholder="Email customer" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="pass_customer" class="input-form" placeholder="Password customer" required></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button type="submit" class="tombol">💾 Simpan</button>
                    <a href="index.php" class="tombol" style="background:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>

</div>

</body>
</html>
<?php
include '../koneksi.php';

if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);

    $query = "DELETE FROM tb_customer WHERE id_customer = '$id'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?pesan=hapus");
    } else {
        header("Location: index.php?pesan=error");
    }
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
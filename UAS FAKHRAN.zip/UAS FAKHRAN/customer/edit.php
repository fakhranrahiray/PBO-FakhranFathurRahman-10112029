<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Customer — Sistem Informasi Gudang</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>

<!-- HEADER -->
<div class="judul">
    <h1>Sistem Informasi Gudang</h1>
    <h2>Edit Data Customer</h2>
</div>

<!-- NAVBAR -->
<div class="navbar">
    <a href="../index.php">🏠 Home</a>
    <div class="dropdown">
        <button class="dropbtn">📦 Data Master ▼</button>
        <div class="dropdown-content">
            <a href="../gudang/index.php">🏭 Data Gudang</a>
            <a href="../barang/index.php">📦 Data Barang</a>
            <a href="../jenis/index.php">🏷️ Data Satuan / Jenis</a>
            <a href="../supplier/index.php">🚚 Data Supplier</a>
            <a href="../customer/index.php">👤 Data Customer</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">🔄 Data Transaksi ▼</button>
        <div class="dropdown-content">
            <a href="../pembelian/index.php">🛒 Transaksi Pembelian</a>
            <a href="../penjualan/index.php">💰 Transaksi Penjualan</a>
        </div>
    </div>
    <div class="dropdown">
        <button class="dropbtn">📊 Laporan ▼</button>
        <div class="dropdown-content">
            <a href="../laporan/penjualan.php">📊 Laporan Penjualan</a>
        </div>
    </div>
</div>

<!-- CONTENT -->
<div class="container">

    <a class="tombol" href="index.php">← Kembali</a>

    <h3>Form Edit Customer</h3>

    <?php
    try {
        include "../koneksi.php";

        if (!$koneksi) throw new Exception("Koneksi ke database gagal.");

        $id    = mysqli_real_escape_string($koneksi, $_GET['id']);
        $query = mysqli_query($koneksi, "SELECT * FROM tb_customer WHERE id_customer = '$id'");

        if (!$query) throw new Exception("Gagal mengambil data customer.");

        $data = mysqli_fetch_array($query);

        if (!$data) {
            echo "<p style='color:red;'>❌ Data customer tidak ditemukan.</p>";
        } else {
    ?>

    <form action="update.php" method="POST">
        <input type="hidden" name="id_customer_lama" value="<?php echo htmlspecialchars($data['id_customer']); ?>">
        <table class="form-table">
            <tr>
                <td>ID Customer</td>
                <td><input type="text" name="id_customer" class="input-form"
                           value="<?php echo htmlspecialchars($data['id_customer']); ?>" required></td>
            </tr>
            <tr>
                <td>Nama Customer</td>
                <td><input type="text" name="nama_customer" class="input-form"
                           value="<?php echo htmlspecialchars($data['nama_customer']); ?>" required></td>
            </tr>
            <tr>
                <td>Jenis Kelamin</td>
                <td>
                    <select name="jenis_kelamin" class="input-form" required>
                        <option value="Laki-laki"  <?php echo $data['jenis_kelamin'] == 'Laki-laki'  ? 'selected' : ''; ?>>Laki-laki</option>
                        <option value="Perempuan"   <?php echo $data['jenis_kelamin'] == 'Perempuan'  ? 'selected' : ''; ?>>Perempuan</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td>Alamat</td>
                <td><textarea name="alamat_customer" class="input-form" rows="3" required><?php echo htmlspecialchars($data['alamat_customer']); ?></textarea></td>
            </tr>
            <tr>
                <td>Telepon</td>
                <td><input type="text" name="telepon_customer" class="input-form"
                           value="<?php echo htmlspecialchars($data['telepon_customer']); ?>" required></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email_customer" class="input-form"
                           value="<?php echo htmlspecialchars($data['email_customer']); ?>" required></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="pass_customer" class="input-form"
                           value="<?php echo htmlspecialchars($data['pass_customer']); ?>" required></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button type="submit" class="tombol">💾 Update</button>
                    <a href="index.php" class="tombol" style="background:#888;">Batal</a>
                </td>
            </tr>
        </table>
    </form>

    <?php
        }
    } catch (Exception $e) {
        echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
    }
    ?>

</div>

</body>
</html>
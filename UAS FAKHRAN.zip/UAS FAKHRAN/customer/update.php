<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_lama          = mysqli_real_escape_string($koneksi, $_POST['id_customer_lama']);
    $id_customer      = mysqli_real_escape_string($koneksi, $_POST['id_customer']);
    $nama_customer    = mysqli_real_escape_string($koneksi, $_POST['nama_customer']);
    $jenis_kelamin    = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $alamat_customer  = mysqli_real_escape_string($koneksi, $_POST['alamat_customer']);
    $telepon_customer = mysqli_real_escape_string($koneksi, $_POST['telepon_customer']);
    $email_customer   = mysqli_real_escape_string($koneksi, $_POST['email_customer']);
    $pass_customer    = mysqli_real_escape_string($koneksi, $_POST['pass_customer']);

    $query = "UPDATE tb_customer SET
                id_customer      = '$id_customer',
                nama_customer    = '$nama_customer',
                jenis_kelamin    = '$jenis_kelamin',
                alamat_customer  = '$alamat_customer',
                telepon_customer = '$telepon_customer',
                email_customer   = '$email_customer',
                pass_customer    = '$pass_customer'
              WHERE id_customer  = '$id_lama'";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?pesan=update");
    } else {
        header("Location: edit.php?id=$id_lama&pesan=error");
    }
    exit;
} else {
    header("Location: index.php");
    exit;
}
?>
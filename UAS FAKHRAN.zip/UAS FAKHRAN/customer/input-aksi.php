<?php
include '../koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_customer      = mysqli_real_escape_string($koneksi, $_POST['id_customer']);
    $nama_customer    = mysqli_real_escape_string($koneksi, $_POST['nama_customer']);
    $jenis_kelamin    = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $alamat_customer  = mysqli_real_escape_string($koneksi, $_POST['alamat_customer']);
    $telepon_customer = mysqli_real_escape_string($koneksi, $_POST['telepon_customer']);
    $email_customer   = mysqli_real_escape_string($koneksi, $_POST['email_customer']);
    $pass_customer    = mysqli_real_escape_string($koneksi, $_POST['pass_customer']);

    $query = "INSERT INTO tb_customer 
              (id_customer, nama_customer, jenis_kelamin, alamat_customer, telepon_customer, email_customer, pass_customer) 
              VALUES 
              ('$id_customer', '$nama_customer', '$jenis_kelamin', '$alamat_customer', '$telepon_customer', '$email_customer', '$pass_customer')";

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php?pesan=input");
    } else {
        header("Location: input.php?pesan=error");
    }
    exit;
} else {
    header("Location: input.php");
    exit;
}
?>